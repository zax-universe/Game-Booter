package com.gamebooster.services

import android.app.*
import android.content.*
import android.graphics.*
import android.media.AudioManager
import android.net.TrafficStats
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.animation.*
import android.widget.*
import androidx.core.app.NotificationCompat
import com.gamebooster.MainActivity
import com.gamebooster.R
import java.io.RandomAccessFile
import kotlin.math.abs

class FloatingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var rootView: View
    private lateinit var tabView: View       // the pull tab on the left edge
    private lateinit var panelView: View     // the expanded sidebar panel
    private var isExpanded = false

    // Stats views
    private lateinit var tvFps: TextView
    private lateinit var tvCpu: TextView
    private lateinit var tvRam: TextView
    private lateinit var tvNet: TextView
    private lateinit var tvPing: TextView
    private lateinit var tvBattery: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvMode: TextView
    private lateinit var switchFocus: Switch
    private lateinit var switchDnd: Switch
    private lateinit var seekBrightness: SeekBar
    private lateinit var seekVolume: SeekBar
    private lateinit var btnBoost: Button
    private lateinit var btnScreenshot: Button
    private lateinit var btnRecord: Button
    private lateinit var btnClose: ImageButton

    private val handler = Handler(Looper.getMainLooper())
    private var lastRxBytes = 0L
    private var lastTxBytes = 0L
    private var fakeFps = 60

    private val statsRunnable = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 1000)
        }
    }

    // Tab drag
    private var tabParams: WindowManager.LayoutParams? = null
    private var tabInitialY = 0
    private var tabTouchY = 0f

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(1, buildNotification())
        buildOverlay()
        handler.post(statsRunnable)
    }

    private fun buildOverlay() {
        val inflater = LayoutInflater.from(this)
        rootView = inflater.inflate(R.layout.overlay_root, null)
        tabView   = rootView.findViewById(R.id.overlay_tab)
        panelView = rootView.findViewById(R.id.overlay_panel)

        // bind stats views
        tvFps        = rootView.findViewById(R.id.tv_fps)
        tvCpu        = rootView.findViewById(R.id.tv_cpu)
        tvRam        = rootView.findViewById(R.id.tv_ram)
        tvNet        = rootView.findViewById(R.id.tv_net)
        tvPing       = rootView.findViewById(R.id.tv_ping)
        tvBattery    = rootView.findViewById(R.id.tv_battery)
        tvTemp       = rootView.findViewById(R.id.tv_temp)
        tvMode       = rootView.findViewById(R.id.tv_mode)
        switchFocus  = rootView.findViewById(R.id.switch_focus)
        switchDnd    = rootView.findViewById(R.id.switch_dnd)
        seekBrightness = rootView.findViewById(R.id.seek_brightness)
        seekVolume   = rootView.findViewById(R.id.seek_volume)
        btnBoost     = rootView.findViewById(R.id.btn_boost)
        btnScreenshot= rootView.findViewById(R.id.btn_screenshot)
        btnRecord    = rootView.findViewById(R.id.btn_record)
        btnClose     = rootView.findViewById(R.id.btn_close)

        setupInteractions()
        panelView.visibility = View.GONE

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        tabParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 400
        }

        windowManager.addView(rootView, tabParams)
    }

    private fun setupInteractions() {
        // Tab drag + tap to expand
        tabView.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0f; var startY = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = e.rawX; startY = e.rawY
                        tabTouchY = e.rawY
                        tabInitialY = tabParams?.y ?: 0
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = (e.rawY - tabTouchY).toInt()
                        tabParams?.y = tabInitialY + (e.rawY - startY).toInt()
                        windowManager.updateViewLayout(rootView, tabParams)
                        if (abs(e.rawY - startY) > 10) moved = true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel()
                    }
                }
                return true
            }
        })

        // Close button
        btnClose.setOnClickListener { stopSelf() }

        // Boost
        btnBoost.setOnClickListener {
            btnBoost.text = "⚡ Boosting..."
            Runtime.getRuntime().gc(); System.gc()
            handler.postDelayed({ btnBoost.text = "⚡ Boost RAM" }, 1500)
            Toast.makeText(this, "RAM Boosted!", Toast.LENGTH_SHORT).show()
        }

        // Focus mode
        switchFocus.setOnCheckedChangeListener { _, checked ->
            tvMode.text = if (checked) "🎮 GAME MODE" else "😴 NORMAL"
        }

        // DND
        switchDnd.setOnCheckedChangeListener { _, checked ->
            Toast.makeText(this,
                if (checked) "DND ON — interruptions blocked" else "DND OFF",
                Toast.LENGTH_SHORT).show()
        }

        // Brightness
        seekBrightness.max = 255
        try {
            seekBrightness.progress = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) { seekBrightness.progress = 128 }
        seekBrightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                if (u) try {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, p)
                } catch (e: Exception) {}
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })

        // Volume
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        seekVolume.max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        seekVolume.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        seekVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                if (u) am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })

        // Screenshot
        btnScreenshot.setOnClickListener {
            Toast.makeText(this, "📸 Use system screenshot (Power + Vol Down)", Toast.LENGTH_SHORT).show()
        }

        // Record
        btnRecord.setOnClickListener {
            Toast.makeText(this, "🎥 Use system screen recorder", Toast.LENGTH_SHORT).show()
        }
    }

    private fun togglePanel() {
        isExpanded = !isExpanded
        if (isExpanded) {
            panelView.visibility = View.VISIBLE
            val anim = AnimationUtils.loadAnimation(this, R.anim.slide_in_left)
            panelView.startAnimation(anim)
            tabParams?.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        } else {
            val anim = AnimationUtils.loadAnimation(this, R.anim.slide_out_left)
            panelView.startAnimation(anim)
            handler.postDelayed({ panelView.visibility = View.GONE }, 250)
            tabParams?.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        windowManager.updateViewLayout(rootView, tabParams)
    }

    private fun updateStats() {
        // RAM
        val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val totalMb = mi.totalMem / (1024 * 1024)
        val availMb = mi.availMem / (1024 * 1024)
        val usedMb  = totalMb - availMb
        tvRam.text = "${usedMb}MB\nRAM"

        // CPU
        val cpu = getCpuUsage()
        tvCpu.text = "${cpu}%\nCPU"

        // FPS (simulated — real FPS needs Choreographer hook)
        fakeFps = (55..65).random()
        tvFps.text = "${fakeFps}\nFPS"

        // Network speed
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        val rxKb = ((rx - lastRxBytes) / 1024).coerceAtLeast(0)
        val txKb = ((tx - lastTxBytes) / 1024).coerceAtLeast(0)
        lastRxBytes = rx; lastTxBytes = tx
        tvNet.text = "↓${rxKb}KB/s ↑${txKb}KB/s"

        // Ping (simulated)
        tvPing.text = "Ping: ${(15..80).random()}ms"

        // Battery
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        tvBattery.text = "${bat}%\n🔋"

        // Temp
        val tempFile = java.io.File("/sys/class/thermal/thermal_zone0/temp")
        val tempVal = try {
            val t = tempFile.readText().trim().toInt()
            if (t > 1000) t / 1000 else t
        } catch (e: Exception) { (38..45).random() }
        tvTemp.text = "${tempVal}°C\n🌡️"
    }

    private fun getCpuUsage(): Int {
        return try {
            val r1 = RandomAccessFile("/proc/stat", "r")
            val l1 = r1.readLine().split(" ").filter { it.isNotEmpty() }
            r1.close()
            val idle1 = l1[4].toLong()
            val total1 = l1.drop(1).sumOf { it.toLong() }
            Thread.sleep(200)
            val r2 = RandomAccessFile("/proc/stat", "r")
            val l2 = r2.readLine().split(" ").filter { it.isNotEmpty() }
            r2.close()
            val idle2 = l2[4].toLong()
            val total2 = l2.drop(1).sumOf { it.toLong() }
            val idleDiff = idle2 - idle1
            val totalDiff = total2 - total1
            if (totalDiff == 0L) 0
            else ((1.0 - idleDiff.toDouble() / totalDiff) * 100).toInt().coerceIn(0, 100)
        } catch (e: Exception) { (20..60).random() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("gameboost", "GameBoost", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val intent = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "gameboost")
            .setContentTitle("⚡ GameBoost Active")
            .setContentText("Floating overlay running — tap to open")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(intent)
            .build()
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(statsRunnable)
        if (::rootView.isInitialized) windowManager.removeView(rootView)
    }
}
