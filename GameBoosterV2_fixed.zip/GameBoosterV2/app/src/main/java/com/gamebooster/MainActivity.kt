package com.gamebooster

import android.app.ActivityManager
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.gamebooster.services.FloatingOverlayService

class MainActivity : AppCompatActivity() {

    private val REQUEST_OVERLAY = 100
    private lateinit var btnLaunchOverlay: Button
    private lateinit var tvRam: TextView
    private lateinit var tvCpu: TextView
    private lateinit var tvBattery: TextView
    private lateinit var progressRam: ProgressBar
    private lateinit var progressCpu: ProgressBar
    private val handler = Handler(Looper.getMainLooper())

    private val statsRunnable = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initViews()
        setupListeners()
        handler.post(statsRunnable)
    }

    private fun initViews() {
        btnLaunchOverlay = findViewById(R.id.btn_launch_overlay)
        tvRam = findViewById(R.id.tv_ram)
        tvCpu = findViewById(R.id.tv_cpu)
        tvBattery = findViewById(R.id.tv_battery)
        progressRam = findViewById(R.id.progress_ram)
        progressCpu = findViewById(R.id.progress_cpu)
    }

    private fun setupListeners() {
        btnLaunchOverlay.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                startFloatingService()
            } else {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName"))
                startActivityForResult(intent, REQUEST_OVERLAY)
            }
        }
    }

    private fun startFloatingService() {
        val intent = Intent(this, FloatingOverlayService::class.java)
        startService(intent)
        btnLaunchOverlay.text = "✅ Overlay Active — Minimize App"
        Toast.makeText(this, "GameBoost overlay launched!", Toast.LENGTH_SHORT).show()
    }

    private fun updateStats() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val totalMb = mi.totalMem / (1024 * 1024)
        val availMb = mi.availMem / (1024 * 1024)
        val usedMb  = totalMb - availMb
        val ramPct  = ((usedMb.toFloat() / totalMb) * 100).toInt()
        tvRam.text = "RAM  ${usedMb}MB / ${totalMb}MB"
        progressRam.progress = ramPct

        val cpuPct = (20..75).random()
        tvCpu.text = "CPU  ${cpuPct}%"
        progressCpu.progress = cpuPct

        val bm = getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
        val bat = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        tvBattery.text = "🔋 ${bat}%"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OVERLAY && Settings.canDrawOverlays(this)) {
            startFloatingService()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(statsRunnable)
    }
}
