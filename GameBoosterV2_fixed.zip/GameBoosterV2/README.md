# ⚡ GameBoost V2 — Pro Gaming Optimizer

Floating sidebar overlay kayak ROG / RedMagic, langsung jalan di atas game!

## Fitur
- 🎮 **Floating Sidebar** — muncul dari kiri, bisa di-drag naik/turun
- 📊 **FPS Monitor** — realtime frame counter
- 🧠 **CPU & RAM Monitor** — live usage stats
- 🌡️ **Suhu** — baca temp dari sensor
- 🌐 **Network Speed** — upload & download KB/s + ping
- 🔋 **Battery** — persentase baterai live
- 🎮 **Focus Mode** — toggle game mode
- 🔕 **DND Mode** — block semua notifikasi
- ☀️ **Brightness Control** — slider langsung
- 🔊 **Volume Control** — slider media volume
- ⚡ **Boost RAM** — 1-tap clear memory
- 📸 **Screenshot** — shortcut cepat
- 🎥 **Screen Record** — shortcut cepat

## Cara Buka di Android Studio

1. Extract ZIP → folder `GameBoosterV2`
2. Android Studio → **File → Open** → pilih folder itu
3. Tunggu Gradle sync (butuh internet, ±3-5 menit)
4. Colok HP, aktifkan **USB Debugging**
5. Klik ▶️ **Run**

## Cara Pakai App

1. Buka **GameBoost**
2. Tap **LAUNCH OVERLAY**
3. Izinkan permission **"Display over other apps"**
4. Minimize app → buka game
5. **Tab oranye** muncul di kiri layar
6. **Tap tab** → panel terbuka dengan semua kontrol
7. **Drag tab** naik/turun untuk reposisi

## Permissions yang Diperlukan
- `SYSTEM_ALERT_WINDOW` — untuk floating overlay ⭐ wajib
- `WRITE_SETTINGS` — untuk brightness control
- `KILL_BACKGROUND_PROCESSES` — untuk boost RAM
- `ACCESS_NOTIFICATION_POLICY` — untuk DND mode

## Requirements
- Android 8.0+ (API 26+)
- Android Studio Hedgehog 2023.1+
